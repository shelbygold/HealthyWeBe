#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_HealthAppStoryBoard1 : NSObject
@end
@implementation PodsDummy_Pods_HealthAppStoryBoard1
@end
